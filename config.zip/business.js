export const DICT_TYPES = [
  'wms_receipt_type', 'wms_shipment_type', 'wms_movement_type','wms_check_type'
]
