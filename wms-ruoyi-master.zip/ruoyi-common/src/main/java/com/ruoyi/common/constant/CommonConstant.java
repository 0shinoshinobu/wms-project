package com.ruoyi.common.constant;

public interface CommonConstant {
    int BATCH_SIZE = 100;
}
