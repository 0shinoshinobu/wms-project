package com.ruoyi.common.pojo.query;

import lombok.Data;

@Data
public class WechatVM {
    private String code;
    private String state;
}
