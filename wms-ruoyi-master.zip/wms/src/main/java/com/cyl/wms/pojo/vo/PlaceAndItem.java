package com.cyl.wms.pojo.vo;

public interface PlaceAndItem {
    Long getItemId();

    Long getWarehouseId();

    Long getAreaId();

    Long getRackId();
}
